package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora();
        calculadora.run();
    }
}
